# Bike-service

This is site for bike service center.

## Simple HTML CSS Website

Pages :

1. Home Page

2. Contac Us page

## You can contribute by adding responsiveness to it.:

1. Add Boostrap componenets

2. media margins

3. anything you found better

### Changes made by oneofthedevs
